export default async function handler(req, res) {
  const fs = require("fs");
  const path = require("path");

  if (req.method !== "POST") {
    return res.status(405).json({ message: "Método não permitido" });
  }

  const { item, nome } = req.body;

  const filePath = path.join(process.cwd(), "data.json");
  const jsonData = fs.readFileSync(filePath);
  const data = JSON.parse(jsonData);

  if (!(item in data)) {
    return res.status(400).json({ message: "Item inválido" });
  }

  data[item] = nome;
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

  res.status(200).json({ message: "Confirmado com sucesso!" });
}
